from django.apps import AppConfig


class SemiRestfulShowsAppConfig(AppConfig):
    name = 'Semi_Restful_Shows_app'
