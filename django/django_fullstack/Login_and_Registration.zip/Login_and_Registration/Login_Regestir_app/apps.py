from django.apps import AppConfig


class LoginRegestirAppConfig(AppConfig):
    name = 'Login_Regestir_app'
