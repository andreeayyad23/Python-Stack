from django.apps import AppConfig


class BookAuthorAppConfig(AppConfig):
    name = 'Book_author_app'
